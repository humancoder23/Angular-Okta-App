module.exports = {
  metadataUrl: 'https://dev-55143921.okta.com/app/exkhc3qf38IMpkefw5d7/sso/saml/metadata',
  entryPoint: 'https://dev-55143921.okta.com/app/dev-55143921_angularokta_1/exkhc3qf38IMpkefw5d7/sso/saml',
  issuer: 'http://www.okta.com/exkhc3qf38IMpkefw5d7',
  privateKey: '-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----'  // Optional
};
