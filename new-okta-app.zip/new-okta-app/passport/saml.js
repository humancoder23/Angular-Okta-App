const passport = require('passport');
const SamlStrategy = require('passport-saml').Strategy;
const axios = require('axios');
const xml2js = require('xml2js');
const oktaConfig = require('../config/okta');

async function configurePassport() {
  try {
    const response = await axios.get(oktaConfig.metadataUrl);
    const metadataXml = response.data;

    const parser = new xml2js.Parser();
    const metadata = await parser.parseStringPromise(metadataXml);

    // Extract the certificate from the parsed metadata
    const cert = metadata['md:EntityDescriptor']['md:IDPSSODescriptor'][0]['md:KeyDescriptor'][0]['ds:KeyInfo'][0]['ds:X509Data'][0]['ds:X509Certificate'][0];

    if (!cert) {
      throw new Error('Certificate not found in metadata');
    }

    passport.use(new SamlStrategy({
      path: '/login/callback',
      entryPoint: oktaConfig.entryPoint,
      issuer: oktaConfig.issuer,
      cert: cert,
      validateInResponseTo: true,
      disableRequestedAuthnContext: true,
      signatureAlgorithm: 'sha256'
    }, (profile, done) => {
      console.log('SAML Profile:', profile);

      // Check if profile is valid (indicating successful signature verification)
      if (profile) {
        console.log('SAML signature verification was successful.');
        return done(null, profile);
      } else {
        console.log('SAML signature verification was unsuccessful.');
        return done(new Error('SAML signature verification failed'), null);
      }
    }));

    passport.serializeUser((user, done) => {
      done(null, user);
    });

    passport.deserializeUser((user, done) => {
      done(null, user);
    });
  } catch (error) {
    console.error('Error fetching metadata:', error);
    process.exit(1);
  }
}

configurePassport();

module.exports = passport;
