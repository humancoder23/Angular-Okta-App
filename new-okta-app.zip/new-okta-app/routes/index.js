const express = require('express');
const passport = require('../passport/saml');
const router = express.Router();
const path = require('path');

// Middleware to check if the session has expired
function checkSession(req, res, next) {
  if (!req.session || !req.session.passport || !req.session.passport.user) {
    return res.redirect('/');
  }
  next();
}

// Default route to serve login.html
router.get('/', (req, res) => {
  const loginPath = path.join(__dirname, '../public', 'login.html');
  res.sendFile(loginPath, (err) => {
    if (err) {
      console.error('Error serving login.html:', err);
      res.status(err.status).end();
    }
  });
});

// SAML login route
router.get('/login',
  passport.authenticate('saml', { failureRedirect: '/', failureFlash: true }),
  (req, res) => {
    res.redirect('/');
  }
);

// SAML login callback route
router.post('/login/callback',
  passport.authenticate('saml', {
    failureRedirect: '/login',
    failureFlash: true
  }), (req, res) => {
    console.log('POST /login/callback');
    res.redirect('/website');
  }
);

// Route for website.html, protected by session check middleware
router.get('/website', checkSession, (req, res) => {
  const websitePath = path.join(__dirname, '../public', 'website.html');
  res.sendFile(websitePath, (err) => {
    if (err) {
      console.error('Error serving website.html:', err);
      res.status(err.status).end();
    }
  });
});

// Route for index.html
router.get('/index', (req, res) => {
  const indexPath = path.join(__dirname, '../public', 'index.html');
  res.sendFile(indexPath, (err) => {
    if (err) {
      console.error('Error serving index.html:', err);
      res.status(err.status).end();
    }
  });
});

// Logout route
router.get('/logout', (req, res) => {
  console.log('GET /logout');
  req.logout(err => {
    if (err) {
      console.error('Error during logout:', err);
      return res.redirect('/');
    }

    req.session.destroy(err => {
      if (err) {
        console.error('Error destroying session:', err);
        return res.redirect('/');
      }
      console.log('Session destroyed. Redirecting to Okta logout.');
      const oktaLogoutUrl = `https://dev-55143921.okta.com/login/signout?post_logout_redirect_uri=http://localhost:9992/login`;
      res.redirect(oktaLogoutUrl);
    });
  });
});

// Catch-all route to serve login.html for any other routes
router.get('*', (req, res) => {
  const loginPath = path.join(__dirname, '../public', 'login.html');
  res.sendFile(loginPath, (err) => {
    if (err) {
      console.error('Error serving login.html:', err);
      res.status(err.status).end();
    }
  });
});

module.exports = router;
